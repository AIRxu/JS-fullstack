import React from 'react';
import './search.styl'; // webpack

class Search extends React.Component {
  render() {
    return (
      <div>Search</div>
    )
  }
}

export default Search;